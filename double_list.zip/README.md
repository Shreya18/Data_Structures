# Double-Linked-List
Double Linked List using C and Structures

1. Create a double linked list with methods to add and delete elements from head and tail positions.
2. Provide method to check whether an element is present in the list.




 
